# Qtop

Python tool for Qt.

---------------------------------------------
This the repo for Qt dependecies for D-Analyst
